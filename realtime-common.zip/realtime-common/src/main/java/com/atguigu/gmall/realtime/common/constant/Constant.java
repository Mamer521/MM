package com.atguigu.gmall.realtime.common.constant;

public class Constant {
    public static final String KAFKA_BROKERS = "hadoop101:9092,hadoop102:9092,hadoop103:9092";

    public static final String TOPIC_DB = "topic_db";

    public static final String TOPIC_LOG = "topic_log";

}
